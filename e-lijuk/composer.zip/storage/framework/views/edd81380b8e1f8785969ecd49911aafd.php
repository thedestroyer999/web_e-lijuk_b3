<li class="nav-item">
    <a class="nav-link " href="dashboard">
        <i class="bi bi-grid"></i>
        <span>Dashboard</span>
    </a>
</li><!-- End Dashboard Nav -->


<li class="nav-item">
    <a class="nav-link collapsed" data-bs-target="#forms-nav" data-bs-toggle="collapse" href="#">
        <i class="bi bi-journal-text"></i><span>Infromasi pelatihan</span><i class="bi bi-chevron-down ms-auto"></i>
    </a>
    <ul id="forms-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
        <li>
            <a href="<?php echo e(route('taman_yang_tersedia')); ?>">Informasi taman yang tersedia</a>
            </a>
        </li>
        <a href="<?php echo e(route('paket_tersedia.index')); ?>">Paket Tersedia</a>
        </a>
        <li>
            <a href="<?php echo e(route('information_input_data_taman')); ?>">Pengisian data taman</a>
            </a>
            <a href="<?php echo e(route('pengisian_paket.index')); ?>">Pengisian Paket</a>
            </a>
        </li>
    </ul>
</li><!-- End Forms Nav -->

<li class="nav-item">
    <a class="nav-link collapsed" data-bs-target="#tables-nav" data-bs-toggle="collapse" href="#">
        <i class="bi bi-layout-text-window-reverse"></i><span>laporan</span><i class="bi bi-chevron-down ms-auto"></i>
    </a>
    <ul id="tables-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
        <li>
            <a href="tables-general.html">
                <a href="<?php echo e(route('laporan_pemesanan.index')); ?>"> Laporan Pemesanan</a>
            </a>
        </li>
        <a href="<?php echo e(route('laporan_pemesanan_ditrima.index')); ?>">Laporan Pemesanan Diterima</a>
        <a href="<?php echo e(route('laporan_pemesanan_ditolak')); ?>">Laporan Pemesanan Ditolak</a>
        </a>

</li>
<li>
    <a href="<?php echo e(route('userdata.show')); ?>"> Data user</a>
    </a>
</li>
</ul>
</li><!-- End Tables Nav -->

<li class="nav-heading">Pages</li>
<a class="nav-link collapsed" href="<?php echo e(url('/admin_profil')); ?>">
    <i class="bi bi-person"></i> <!-- Icon profil -->
    <span>Profil Admin</span>
</a>

</a>
<li class="nav-item">
    <a class="nav-link collapsed" href="<?php echo e(route('login')); ?>">
        <i class="bi bi-box-arrow-in-right"></i>
        <span>Keluar</span>
    </a>
</li><?php /**PATH C:\Users\johan\laravel\e-lijuk\resources\views/includes/sidebar.blade.php ENDPATH**/ ?>