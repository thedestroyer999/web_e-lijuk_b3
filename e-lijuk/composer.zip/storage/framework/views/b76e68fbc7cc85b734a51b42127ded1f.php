<form action="<?php echo e(route('insert.data')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input type="text" name="field_name" placeholder="Masukkan data">
    <!-- tambahkan input lain sesuai kebutuhan -->
    <button type="submit">Simpan</button>
</form>
<?php /**PATH C:\project\e-lijuk\resources\views/insert_data_form.blade.php ENDPATH**/ ?>