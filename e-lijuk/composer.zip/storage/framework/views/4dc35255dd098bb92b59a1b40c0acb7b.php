<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>E-LIJUK</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?php echo e(asset('assets/css/stylee.css')); ?>" rel="stylesheet">

  <!-- Custom CSS for Background -->
  <style>
    body {
      background-image: url('assets/img/background6 .jpg');
      background-size: cover;
      background-position: center;
      background-attachment: fixed;
    }
  </style>
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">
      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#about">Tentang Kami</a></li>
          <li><a class="nav-link scrollto" href="#contact">Kontak</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->
    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="hero d-flex align-items-center" style="background-image: url('assets/img/background6 .jpg');">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 d-flex flex-column justify-content-center">
          <h1 data-aos="fade-up" style="font-family: 'Archivo Black', sans-serif; color: white;">SELAMAT DATANG DI WEBSITE E-LIJUK</h1>
          <h2 data-aos="fade-up" style="font-family: 'Archivo Black', sans-serif; color: white;" data-aos-delay="400">Edukasi-Limbah-Nganjuk</h2>
          <div data-aos="fade-up" data-aos-delay="600">
            <div class="text-center text-lg-start">
              <a href="<?php echo e(route('login')); ?>" class="btn btn-primary mt-5">Login <i class="bi bi-arrow-right"></i></a>
              </div>
          </div>
        </div>
        <div class="col-lg-6" data-aos="zoom-out" data-aos-delay="100">
    <img src="assets/img/E-LIJUK2.png" class="img-fluid" alt="" style="width: 80%; height: 80;">
</div>

        </div>
      </div>
    </div>

  </section><!-- End Hero -->

  <main id="main">
    <!-- ======= About Section ======= -->
    <section id="about" class="about">
    <div class="container" data-aos="fade-up">
        <div class="row gx-0">
            <div class="col-lg-6 d-flex flex-column justify-content-center" data-aos="fade-up" data-aos-delay="200">
                <div class="content">
                    <h3 style="font-size: 2em; color: black;">E-lijuk website</h3>
                    <h2>Website Elijuk adalah platform eksklusif untuk admin, menyediakan fitur untuk melaporkan pembelian tiket, mengunggah informasi pelatihan taman dan manajemen limbah, serta mengelola secara efisien.</h2>
                    <div class="text-center text-lg-start"></div>
                </div>
            </div>
            <div class="col-lg-6 d-flex align-items-stretch" data-aos="zoom-out" data-aos-delay="200">
                <img src="assets/img/dlh2.jpg" class="img-fluid" alt="" style="max-width: 90%; max-height: 90%;">
            </div>
        </div>
    </div>
    <div class="col-lg-6"></div>
    <div class="swiper-pagination"></div>
</section>
    </section><!-- End Testimonials Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container text-center" data-aos="fade-up">
        <header class="section-header">
          <p>Kontak Kami</p>
        </header>
        <div class="row gy-4">
          <div class="col-lg-6 mx-auto">
            <div class="row gy-4">
              <div class="col-md-6">
                <div class="info-box">
                  <i class="bi bi-geo-alt"></i>
                  <h3>Alamat</h3>
                  <p>Jl. Raya Kedondong No.0<br>Sanggrahan, Kedondong, Kec. Bagor, Kabupaten Nganjuk, Jawa Timur 64461</p>
                </div>
              </div>
              <div class="col-md-6">
                <div class="info-box">
                  <i class="bi bi-telephone"></i>
                  <h3>No telp</h3>
                  <p>08123146513<br>093648821649</p>
                </div>
              </div>
              <div class="col-md-6">
                <div class="info-box">
                  <i class="bi bi-envelope"></i>
                  <h3>Email kami</h3>
                  <p>Dlhnganjuk@gmail.com<br>Tifb3@gmail.com</p>
                </div>
              </div>
              <div class="col-md-6">
                <div class="info-box">
                  <i class="bi bi-clock"></i>
                  <h3>Jam buka-tutup</h3>
                  <p>Monday - Friday<br>8:00AM - 9:00PM</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

    <!-- Vendor JS Files -->
    <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
    <script src="assets/vendor/aos/aos.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>

    <!-- Template Main JS File -->
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\Users\johan\laravel\e-lijuk\resources\views/landing_page.blade.php ENDPATH**/ ?>