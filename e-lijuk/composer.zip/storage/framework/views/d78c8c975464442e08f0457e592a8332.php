<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Taman tersedia</title>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.css">
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">
    <div class="d-flex align-items-center justify-content-between">
      <a href="dashboard" class="logo d-flex align-items-center">
        <img src="assets/img/E-LIJUK2.png" alt="" style="width: 30px; height: 40px; object-fit: cover; aspect-ratio: 1/1;">
        <span class="logo-text">E-LIJUK</span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div>
    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">
        <li class="nav-item d-block d-lg-none">
          <a class="nav-link nav-icon search-bar-toggle " href="#">
            <i class="bi bi-search"></i>
          </a>
        </li>
      </ul>
    </nav>
  </header>

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
    <ul class="sidebar-nav" id="sidebar-nav">
      <!-- Include Sidebar Content Here -->
      <?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </ul>
  </aside>
  <div>
    <main id="main" class="main">
      <h5 class="card-title">Taman tersedia</h5>
      <table id="myTable" class="table table-striped table-bordered">
        <thead>
          <tr>
            <th scope="col">No</th>
            <th scope="col">Gambar</th>
            <th scope="col">Nama</th>
            <th scope="col">Deskripsi</th>
            <th scope="col">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $i = 1; // Inisialisasi variabel hitungan
          ?>
          <?php if($dataTaman->count() > 0): ?>
          <?php $__currentLoopData = $dataTaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td scope="row"><?php echo e($i++); ?></td>
            <td><img width="150px" src="<?php echo e(url('/data_taman/'.$t->foto)); ?>"></td>
            <td><?php echo e($t->nama_taman); ?></td>
            <td><?php echo e($t->deskripsi); ?></td>
            <td>
              <form id="deleteForm_<?php echo e($t->id_taman); ?>" action="<?php echo e(route('taman.destroy', $t->id_taman)); ?>" method="POST" class="btn btn-danger p-0">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="button" class="btn btn-danger deleteBtn" onclick="confirmDelete('deleteForm_<?php echo e($t->id_taman); ?>')">Hapus</button>
              </form>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
          <tr>
            <td class="text-center" colspan="5">Tidak ada data taman</td>
          </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </main>
  </div>

  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.umd.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/js/main.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.js"></script>
  <script>
    // Fungsi untuk menampilkan konfirmasi penghapusan dengan SweetAlert2
    function confirmDelete(formId) {
      Swal.fire({
        title: 'Apakah Anda yakin?',
        text: "Anda tidak akan dapat mengembalikan ini!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',


        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Ya, hapus saja!'
      }).then((result) => {
        if (result.isConfirmed) {
          // Jika dikonfirmasi, kirimkan form penghapusan
          document.getElementById(formId).submit();
        }
      });
    }

    $(document).ready(function() {
        $('#myTable').DataTable();
    });
  </script>


</body>

</html>
<?php /**PATH C:\project\e-lijuk\resources\views/taman_yang_tersedia.blade.php ENDPATH**/ ?>