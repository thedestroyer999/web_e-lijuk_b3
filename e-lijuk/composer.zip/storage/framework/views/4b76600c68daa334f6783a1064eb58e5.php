<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Pemesanan</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->


  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">


  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: NiceAdmin
  * Updated: Jan 29 2024 with Bootstrap v5.3.2
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
  <style>
    body {
      background-image: url('assets/img/background12.jpg');
      background-size: cover;
      background-position: center;
    }
  </style>
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">
    <div class="d-flex align-items-center justify-content-between">
      <a href="dashboard" class="logo d-flex align-items-center">
        <img src="assets/img/E-LIJUK2.png" alt="" style="width: 30px; height: 40px; object-fit: cover; aspect-ratio: 1/1;">
        <span class="logo-text">E-LIJUK</span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div>
    </div><!-- End Logo -->

    <div class="search-bar">
      <form class="search-form d-flex align-items-center" method="POST" action="#">
        <input type="text" name="query" placeholder="Search" title="Enter search keyword">
        <button type="submit" title="Search"><i class="bi bi-search"></i></button>
      </form>
    </div><!-- End Search Bar -->

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

        <li class="nav-item d-block d-lg-none">
          <a class="nav-link nav-icon search-bar-toggle " href="#">
            <i class="bi bi-search"></i>


    </nav><!-- End Icons Navigation -->

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      <?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;<!-- End Login Page Nav -->
    </ul>
  </aside><!-- End Sidebar-->
  <div>
    <main id="main" class="main">
      <h5 class="card-title">Laporan pemesanan ditrima</h5>
      <table class="table table-striped table-bordered">
        <thead>
          <tr>
            <th scope="col">No</th>
            <th scope="col">Nama pemesan</th>
            <th scope="col">No whattsapp</th>
            <th scope="col">Jenjang pendidikan</th>
            <th scope="col">Jumlah peserta</th>
            <th scope="col">Waktu pemesanan</th>
            <th scope="col">Tanggal pemesanan</th>
            <th scope="col">Aksi</th> <!-- Kolom baru untuk tombol aksi -->
          </tr>
        </thead>
        <tbody>
          <?php
          $i = 1; // Inisialisasi variabel hitungan
          ?>
          <?php if($dataPemesanan->where('status', 'ditrima')->count() > 0): ?>
          <?php $__currentLoopData = $dataPemesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($pp->status == 'ditrima'): ?>
          <tr>
            <td scope="row"><?php echo e($i++); ?></td>
            <td><?php echo e($pp->nama_pengguna); ?></td>
            <td><?php echo e($pp->no_whatsapp); ?></td>
            <td><?php echo e($pp->jenjang_pendidikan); ?></td>
            <td><?php echo e($pp->jumlah_peserta); ?></td>
            <td><?php echo e($pp->tanggal_booking); ?></td>
            <td><?php echo e($pp->tanggal_pesan); ?></td>
            <td>
              <form id="deleteForm_<?php echo e($pp->id_pemesanan); ?>" action="<?php echo e(route('pemesanan.destroy', $pp->id_pemesanan)); ?>" method="POST" class="btn btn-danger p-0">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="button" class="btn btn-danger deleteBtn" onclick="confirmDelete('deleteForm_<?php echo e($pp->id_pemesanan); ?>')">Hapus</button>
              </form>
            </td>
          </tr>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
          <tr>
            <td class="text-center" colspan="8">Tidak ada pemesanan diterima</td>
          </tr>
          <?php endif; ?>
          <!-- Baris-baris lainnya -->
        </tbody>
      </table>
    </main>
  </div>

  </div><!-- End Left side columns -->

  <!-- Right side columns -->
  <div class="col-lg-4">
  </div><!-- End Right side columns -->

  </div>
  </section>

  </main><!-- End #main -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.umd.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
  <script>
    // Fungsi untuk menampilkan konfirmasi penghapusan dengan SweetAlert2
    function confirmDelete(formId) {
      Swal.fire({
        title: 'Apakah Anda yakin?',
        text: "Anda tidak akan dapat mengembalikan ini!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Ya, hapus saja!'
      }).then((result) => {
        if (result.isConfirmed) {
          // Jika dikonfirmasi, kirimkan form penghapusan
          document.getElementById(formId).submit();
        }
      });
    }
  </script>

</body>

</html><?php /**PATH C:\Users\johan\laravel\e-lijuk\resources\views/laporan_pemesanan_ditrima.blade.php ENDPATH**/ ?>