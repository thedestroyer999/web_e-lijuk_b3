<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Profil admin</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</head>

<body>

  <header id="header" class="header fixed-top d-flex align-items-center">
    <div class="d-flex align-items-center justify-content-between">
      <a href="dashboard" class="logo d-flex align-items-center">
        <img src="assets/img/E-LIJUK2.png" alt="" style="width: 30px; height: 40px; object-fit: cover; aspect-ratio: 1/1;">
        <span class="logo-text">E-LIJUK</span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div>
  </header><!-- End Header -->

  <aside id="sidebar" class="sidebar">
    <ul class="sidebar-nav" id="sidebar-nav">
      @include('includes.sidebar')<!-- End Login Page Nav -->
    </ul>
  </aside>
  <!-- End Sidebar-->

  <main id="main" class="main">
    <div class="pagetitle">
      <h1>Profil</h1>
      <nav>
      </nav>
    </div><!-- End Page Title -->

    @if (session('success'))
    <div class="alert alert-success">
      {{ session('success') }}
    </div>
    @endif

    @if ($errors->any())
    <div class="alert alert-danger">
      <ul>
        @foreach ($errors->all() as $error)
        <li>{{ $error }}</li>
        @endforeach
      </ul>
    </div>
    @endif

    <ul class="nav nav-tabs nav-tabs-bordered">
      <li class="nav-item">
        <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#profile-overview">Profil</button>
      </li>
      <li class="nav-item">
        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-change-password">Edit profil admin</button>
      </li>
    </ul>

    <div class="tab-content pt-2">
      <div class="tab-pane fade show active profile-overview" id="profile-overview">
        <h5 class="card-title">Detail profil admin</h5>
        <div class="row">
          <div class="col-lg-3 col-md-4 label">Email</div>
          <div class="col-lg-9 col-md-8">{{ $email }}</div>
        </div>
      </div>

      <div class="tab-pane fade profile-edit pt-3" id="profile-edit">
      </div>

      <div class="tab-pane fade pt-3" id="profile-settings">
      </div>

      <form action="{{ route('update.password')}}" method="post">
        @csrf
        <div class="tab-pane fade pt-3" id="profile-change-password">
          <!-- Change Password Form -->
          <div class="row mb-3">
            <label for="currentPassword" class="col-md-4 col-lg-3 col-form-label">Kata sandi lama</label>
            <div class="col-md-8 col-lg-9">
              <input name="current_password" type="password" class="form-control" id="currentPassword">
            </div>
          </div>

          <div class="row mb-3">
            <label for="newPassword" class="col-md-4 col-lg-3 col-form-label">Kata sandi baru</label>
            <div class="col-md-8 col-lg-9">
              <input name="new_password" type="password" class="form-control" id="newPassword">
            </div>
          </div>

          <div class="row mb-3">
            <label for="renewPassword" class="col-md-4 col-lg-3 col-form-label">Konfirmasi kata sandi</label>
            <div class="col-md-8 col-lg-9">
              <input name="renew_password" type="password" class="form-control" id="renewPassword">
            </div>
          </div>

          <div class="text-center">
            <button type="submit" class="btn btn-primary">Perbarui</button>
          </div>
        </div><!-- End Change Password Form -->
      </form>
    </div>
  </main><!-- End #main -->

  <footer id="footer" class="footer">
    <div class="copyright">
    </div>
    <div class="credits">
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.umd.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

  <script>
    document.querySelector('form').addEventListener('submit', function(event) {
      var currentPassword = document.getElementById('currentPassword').value;
      var newPassword = document.getElementById('newPassword').value;
      var renewPassword = document.getElementById('renewPassword').value;

        // Check if current password is empty
        if (!currentPassword) {
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Mohon isi kata sandi lama!',
        });
        event.preventDefault();
        return;
      }

      // Check if new password is empty
      if (!newPassword) {
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Mohon isi kata sandi baru!',
        });
        event.preventDefault();
        return;
      }

      // Check if renew password is empty
      if (!renewPassword) {
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Mohon isi konfirmasi kata sandi!',
        });
        event.preventDefault();
        return;
      }
      // Check if passwords contain spaces
      if (/\s/.test(newPassword) || /\s/.test(renewPassword)) {
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Password tidak boleh mengandung spasi!',
        });
        event.preventDefault();
        return;
      }

      // Check if new passwords match
      if (newPassword !== renewPassword) {
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Konfirmasi kata sandi tidak sesuai!',
        });
        event.preventDefault();
        return;
      }

      // Add any additional validation checks here
    });
  </script>

</body>

</html>
